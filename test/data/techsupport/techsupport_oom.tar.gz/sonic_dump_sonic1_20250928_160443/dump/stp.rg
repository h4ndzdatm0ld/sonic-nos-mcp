Spanning-tree is not configured
