      3938720 K total memory
      2181080 K used memory
       306348 K active memory
      2102012 K inactive memory
       984504 K free memory
        30044 K buffer memory
      1012448 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
         7260 non-nice user cpu ticks
          870 nice user cpu ticks
         5670 system cpu ticks
        29059 idle cpu ticks
          496 IO-wait cpu ticks
            0 IRQ cpu ticks
          189 softirq cpu ticks
            3 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       792013 K paged in
        71061 K paged out
            0 pages swapped in
            0 pages swapped out
       915254 interrupts
      2382653 CPU context switches
   1759075284 boot time
        17497 forks
