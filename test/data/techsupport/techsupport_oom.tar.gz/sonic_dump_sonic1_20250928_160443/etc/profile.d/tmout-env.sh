

tty | grep -q tty &&  \
export TMOUT=900
