      3938728 K total memory
      2573060 K used memory
       384324 K active memory
      2488296 K inactive memory
       405404 K free memory
        78284 K buffer memory
      1168648 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       135388 non-nice user cpu ticks
         1092 nice user cpu ticks
        55185 system cpu ticks
      6423353 idle cpu ticks
         8607 IO-wait cpu ticks
            0 IRQ cpu ticks
        11400 softirq cpu ticks
          221 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       910849 K paged in
       663568 K paged out
            0 pages swapped in
            0 pages swapped out
     24353420 interrupts
     42351214 CPU context switches
   1759038183 boot time
        85135 forks
