      3938728 K total memory
      1657012 K used memory
       403856 K active memory
      1916464 K inactive memory
      1303120 K free memory
        81172 K buffer memory
      1180808 K swap cache
            0 K total swap
            0 K used swap
            0 K free swap
       136838 non-nice user cpu ticks
         2397 nice user cpu ticks
        57009 system cpu ticks
      6450169 idle cpu ticks
         8767 IO-wait cpu ticks
            0 IRQ cpu ticks
        11479 softirq cpu ticks
          223 stolen cpu ticks
            0 non-nice guest cpu ticks
            0 nice guest cpu ticks
       924911 K paged in
       690820 K paged out
            0 pages swapped in
            0 pages swapped out
     24559211 interrupts
     42982210 CPU context switches
   1759038183 boot time
        90988 forks
